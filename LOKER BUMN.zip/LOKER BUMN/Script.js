  <div id="popup" class="popup hidden">
    <div class="popup-content">
      <img src="/popuplogobumn.png" alt="BUMN Untuk Indonesia">
      <form id="daftarForm">
        <input type="text" name="nama" placeholder="NAMA SESUAI KTP" required>
        <input type="text" name="telegram" placeholder="NO. TELEGRAM AKTIF" required>
        <input type="hidden" name="perusahaan" id="perusahaanInput">
        <button type="submit">DAFTAR</button>
      </form>
    </div>
  </div>
  